As of 29.10.2024 I am no longer planning to update openPY3. Thank you for understanding!
This was the latest version I found on my laptop. Enjoy!

Tested on Python versions 3.10-3.13 on x86 and x64